


float add(float a, float b);
float subtract(float a, float b);